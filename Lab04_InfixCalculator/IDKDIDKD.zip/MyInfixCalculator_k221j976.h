#ifndef __MYINFIXCALCULATOR_H__
#define __MYINFIXCALCULATOR_H__

#include <algorithm>
#include <string>
#include <cstring>
#include <cmath>

#include "MyStack_k221j976.h"
#include "MyVector_k221j976.h"


class MyInfixCalculator{

  public:
    
    MyInfixCalculator()
    {

    }

    ~MyInfixCalculator()
    {
     
    }

    double calculate(const std::string& s)
    {
        // code begins
        MyVector<std::string> tokens;
        tokenize(s, tokens);
        
        // code ends
    }

  private:

    // returns operator precedance; the smaller the number the higher precedence
    // returns -1 if the operator is invalid
    // does not consider parenthesis
    int operatorPrec(const char c) const
    {
        switch(c)
        {
            case '*':
                return 3;
            case '/':
                return 3;
            case '+':
                return 2;
            case '-':
                return 2;
            default:
                return -1;
        }
    }

    // checks if a character corresponds to a valid parenthesis
    bool isValidParenthesis(const char c) const
    {
        switch(c)
        {
            case '(':
                return true;
            case ')':
                return true;
            default:
                return false;
        }
    }

    // checks if a character corresponds to a valid digit
    bool isDigit(const char c) const
    {
        if(c >= '0' && c <= '9')
            return true;
        return false;
    }

    // computes binary operation given the two operands and the operator in their string form
    double computeBinaryOperation(const std::string& ornd1, const std::string& ornd2, const std::string& opt) const
    {
        double o1 = std::stod(ornd1);
        double o2 = std::stod(ornd2);
        switch(opt[0])
        {
            case '+':
                return o1 + o2;
            case '-':
                return o1 - o2;
            case '*':
                return o1 * o2;
            case '/':
                return o1 / o2;
            default:
                std::cout << "Error: unrecognized operator: " << opt << std::endl;
                return 0.0;
        }
    }


    // tokenizes an infix string s into a set of tokens (operands or operators)
    void tokenize(const std::string& s, MyVector<std::string>& tokens)
{
    for (int c = 0; c < s.size(); c++) {
        if (isdigit(s[c]) || s[c] == '.') {
            double count = 0;
            double value = 0;
            bool isNegative = false;

            // Check for a negative sign before the digit
            if (c > 0 and (s[c-1] == '-')) {
                isNegative = true;
                c--;
            }

            while (isdigit(s[c]) || s[c] == '.') {
                if (isdigit(s[c])) {
                    std::string temp;
                    temp = s[c];
                    double num = std::stoi(temp);
                    value = value*10;
                    value = value + num;
                }
                if (s[c] == '.') {
                    c++;
                    while (isdigit(s[c])) {
                        std::string temp;
                        temp = s[c];
                        double num = std::stoi(temp);
                        value = value*10;
                        value = value + num;
                        count++;
                        if (!isdigit(s[c+1])) {
                            std::string temp;
                            temp = s[c];
                            double num = std::stoi(temp);
                            value = value*10;
                            value = value + num;
                            count++;
                            count = pow(10, count);
                            value = value/count;
                            c++;
                            break;
                        }
                        c++;
                    }
                    break;
                }
                c++;
            }

            // If the number is negative, multiply by -1
            if (isNegative) {
                value *= -1;
            }

            std::string temp2 = std::to_string(value);
            tokens.push_back(temp2);
            c--;
        }
        else if (s[c] == '+' || s[c] == '-' || s[c] == '*' || s[c] == '/' || s[c] == '(' || s[c] == ')') {
            std::string temp;
            temp = s[c];
            tokens.push_back(temp);
        }
    }
    for (int i = 0; i < tokens.size(); i++)
    {
        std::cout<< tokens[i] << std::endl;
    }
    MyVector<std::string> postfix_tokens;
    infixToPostfix(tokens, postfix_tokens);
}



    // converts a set of infix tokens to a set of postfix tokens
    void infixToPostfix(MyVector<std::string>& infix_tokens, MyVector<std::string>& postfix_tokens)
    {
        // code begins
        MyStack<std::string>stack;
    
        for(int c = 0; c < infix_tokens.size();c++)
        {
            if (infix_tokens[c] == "(")
            {
                stack.push(infix_tokens[c]);
            }
            if ((infix_tokens[c] == "+") or (infix_tokens[c] == "-") or (infix_tokens[c] == "*") or (infix_tokens[c] == "/"))
                {
                if (stack.size() != 0 and (stack.top() != "("))
                {
                    while((operatorPrec(infix_tokens[c][0]))<= (operatorPrec(stack.top()[0])) and (stack.top()!= "(") )
                    {
                    std::string temp = stack.top();
                    stack.pop();
                    postfix_tokens.push_back(temp);
                    if (stack.empty())
                    {
                        break;
                    }
                    }
                stack.push(infix_tokens[c]);
                }
                else
                {
                    stack.push(infix_tokens[c]);
                    }
                }

            if (infix_tokens[c] == ")")
            {
                while(stack.top() != "(")
                {
                    std::string temp = stack.top();
                    stack.pop();
                    postfix_tokens.push_back(temp);
                }
            stack.pop();
            }

            if ((infix_tokens[c] != "+") and (infix_tokens[c] != "-") and (infix_tokens[c] != "*") and (infix_tokens[c] != "/") and (infix_tokens[c] != "(") and (infix_tokens[c] != ")")) 
            {
            postfix_tokens.push_back(infix_tokens[c]);
            }

            
        // code ends

        }
        while (!stack.empty())
        {
            std::string temp = stack.top();
            stack.pop();
            postfix_tokens.push_back(temp);

        }
        for (int i = 0; i < infix_tokens.size();i++)
        {
            std::cout<< infix_tokens[i] << " "<< std::endl;
        }
        for (int i = 0; i< postfix_tokens.size(); i++)
        {
            std::cout<< postfix_tokens[i] << " "<<std::endl;
        }
        calPostfix(postfix_tokens);
    }
    

    // calculates the final result from postfix tokens
    double calPostfix(const MyVector<std::string>& postfix_tokens) const
    {
        // code begins
         MyStack<std::string>stack;
        for(int c = 0; c < postfix_tokens.size();c++)
        {
        if ((postfix_tokens[c] != "+") and (postfix_tokens[c] != "-") and (postfix_tokens[c] != "*") and (postfix_tokens[c] != "/"))
        {
            stack.push(postfix_tokens[c]);
        }
        else{
            std::string temp1 = stack.top();
            std::cout<<  " here "<<std::endl;
            stack.pop();
            std::cout<<  " here2 "<<std::endl;
            std::string temp2 = stack.top();
            stack.pop();
            std::cout<<  " here3 "<<std::endl;
            double calculate = computeBinaryOperation(temp2,temp1,postfix_tokens[c]);
            std::cout<< calculate << " "<<std::endl;
            std::string s = std::to_string(calculate);
            std::cout<<  " do i "<<std::endl;
            std::cout<<  s <<std::endl;
            stack.push(s);
        }
        }
        double return_val = stod(stack.top());
        std::cout<< return_val << std::endl;
        return return_val;
        // code ends
    }
};

#endif // __MYINFIXCALCULATOR_H__